package com.tickets.TicketReservationSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketReservationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketReservationSystemApplication.class, args);
	}

}
